import { Link } from "react-router-dom";
import { ArrowRight, Globe, Award, Factory, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import { useLanguage } from "@/i18n/LanguageContext";
import heroImg from "@/assets/hero-factory.jpg";
import tagsImg from "@/assets/products-tags.jpg";
import stickersImg from "@/assets/products-stickers.jpg";
import boxesImg from "@/assets/products-boxes.jpg";

const featureIcons = [Globe, Award, Factory, ShieldCheck];
const productImages = [tagsImg, stickersImg, boxesImg];

const Index = () => {
  const { t } = useLanguage();
  const stats = t("index.stats") as { value: string; label: string }[];
  const features = t("index.features") as { title: string; desc: string }[];
  const highlights = t("index.productHighlights") as { title: string; desc: string }[];

  return (
    <Layout>
      {/* Hero */}
      <section className="relative flex min-h-[520px] items-center overflow-hidden lg:min-h-[600px]">
        <img src={heroImg} alt="Label Masters" className="absolute inset-0 h-full w-full object-cover" width={1920} height={1080} />
        <div className="overlay-dark absolute inset-0" />
        <div className="container-narrow relative z-10 mx-auto px-4 py-20 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="mb-3 text-sm font-medium uppercase tracking-widest text-accent opacity-90 animate-fade-in" style={{ animationDelay: "0.1s" }}>
              {t("index.heroTag") as string}
            </p>
            <h1 className="mb-5 text-3xl font-extrabold leading-tight tracking-tight text-primary-foreground sm:text-4xl lg:text-5xl animate-fade-in" style={{ animationDelay: "0.2s" }}>
              {t("index.heroTitle1") as string}
              <br />
              {t("index.heroTitle2") as string}
            </h1>
            <p className="mb-8 max-w-lg text-base leading-relaxed text-primary-foreground/80 sm:text-lg animate-fade-in" style={{ animationDelay: "0.3s" }}>
              {t("index.heroDesc") as string}
            </p>
            <div className="flex flex-wrap gap-3 animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <Button asChild size="lg" className="gradient-accent border-0 text-accent-foreground font-semibold">
                <Link to="/products">{t("index.viewProducts") as string} <ArrowRight className="ml-1 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/contact">{t("index.contactUs") as string}</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-b border-border bg-card">
        <div className="container-narrow mx-auto grid grid-cols-2 gap-6 px-4 py-10 sm:px-6 md:grid-cols-4 lg:px-8">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <p className="text-2xl font-extrabold text-accent sm:text-3xl">{s.value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="section-padding bg-background">
        <div className="container-narrow mx-auto">
          <h2 className="mb-2 text-center text-sm font-semibold uppercase tracking-widest text-accent">{t("index.whyUs") as string}</h2>
          <p className="mb-12 text-center text-2xl font-bold text-foreground sm:text-3xl">{t("index.whyUsTitle") as string}</p>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f, i) => {
              const Icon = featureIcons[i];
              return (
                <div key={i} className="rounded-lg border border-border bg-card p-6 shadow-card transition-shadow hover:shadow-elevated">
                  <Icon className="mb-4 h-8 w-8 text-accent" />
                  <h3 className="mb-2 text-lg font-semibold text-foreground">{f.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Product Highlights */}
      <section className="section-padding bg-secondary/50">
        <div className="container-narrow mx-auto">
          <h2 className="mb-2 text-center text-sm font-semibold uppercase tracking-widest text-accent">{t("index.featured") as string}</h2>
          <p className="mb-12 text-center text-2xl font-bold text-foreground sm:text-3xl">{t("index.featuredTitle") as string}</p>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {highlights.map((p, i) => (
              <Link
                key={i}
                to="/products"
                className="group overflow-hidden rounded-lg border border-border bg-card shadow-card transition-all hover:shadow-elevated"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img src={productImages[i]} alt={p.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                </div>
                <div className="p-5">
                  <h3 className="mb-1 text-lg font-semibold text-foreground">{p.title}</h3>
                  <p className="text-sm text-muted-foreground">{p.desc}</p>
                </div>
              </Link>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Button asChild variant="outline" size="lg">
              <Link to="/products">{t("index.viewAll") as string} <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="gradient-hero section-padding">
        <div className="container-narrow mx-auto text-center">
          <h2 className="mb-4 text-2xl font-bold text-primary-foreground sm:text-3xl">{t("index.ctaTitle") as string}</h2>
          <p className="mx-auto mb-8 max-w-lg text-base text-primary-foreground/70">{t("index.ctaDesc") as string}</p>
          <Button asChild size="lg" className="gradient-accent border-0 font-semibold text-accent-foreground">
            <Link to="/contact">{t("index.ctaButton") as string} <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
